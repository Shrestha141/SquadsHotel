package com.spring.hibernate.squadsHotel.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "location")
public class Location {
	@Id
	@GeneratedValue
	private long id;
	private String name;
	private String place;
	private long lat;
	private long log;
	private String checkInDate;
	private String checkOutDate;
	private int rooms;
	private int guest;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public long getLat() {
		return lat;
	}
	public void setLat(long lat) {
		this.lat = lat;
	}
	public long getLog() {
		return log;
	}
	public void setLog(long log) {
		this.log = log;
	}
	public String getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}
	public String getCheckOutDate() {
		return checkOutDate;
	}
	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}
	public int getRooms() {
		return rooms;
	}
	public void setRooms(int rooms) {
		this.rooms = rooms;
	}
	public int getGuest() {
		return guest;
	}
	public void setGuest(int guest) {
		this.guest = guest;
	}
	@Override
	public String toString() {
		return "Location [id=" + id + ", name=" + name + ", place=" + place + ", lat=" + lat + ", log=" + log
				+ ", checkInDate=" + checkInDate + ", checkOutDate=" + checkOutDate + ", rooms=" + rooms + ", guest="
				+ guest + "]";
	}
	
	
	
	
	

}
