package com.spring.hibernate.squadsHotel.repo;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.hibernate.squadsHotel.model.Location;



public interface LocationRepo extends JpaRepository<Location, Long>{

	List<Location> findByplace(String place);
	List<Location> findByname(String place);


}
