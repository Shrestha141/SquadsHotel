package com.spring.hibernate.squadsHotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SquadsHotelApplication {

	public static void main(String[] args) {
		SpringApplication.run(SquadsHotelApplication.class, args);
	}

}
