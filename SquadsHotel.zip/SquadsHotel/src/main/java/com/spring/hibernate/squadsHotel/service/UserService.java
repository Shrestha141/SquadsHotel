package com.spring.hibernate.squadsHotel.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.spring.hibernate.squadsHotel.controller.dto.UserRegistrationDto;
import com.spring.hibernate.squadsHotel.model.User;


public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
