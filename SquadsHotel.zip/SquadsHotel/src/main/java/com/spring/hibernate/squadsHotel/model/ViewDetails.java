package com.spring.hibernate.squadsHotel.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class ViewDetails {

	@Id
	@GeneratedValue
	private int roomId;
	private String name;
    private String checkin;
    private String checkout;
    private int Guestconfig;
    private int Roomconfig;
    private int starRating;
    private String currency;
    private String description;
    private String created;
    private String updated;
    private int offersCuponId;
    private int BookNowBookingId;
    
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public String getCheckin() {
		return checkin;
	}
	public void setCheckin(String checkin) {
		this.checkin = checkin;
	}
	public String getCheckout() {
		return checkout;
	}
	public void setCheckout(String checkout) {
		this.checkout = checkout;
	}
	public int getGuestconfig() {
		return Guestconfig;
	}
	public void setGuestconfig(int guestconfig) {
		Guestconfig = guestconfig;
	}
	public int getRoomconfig() {
		return Roomconfig;
	}
	public void setRoomconfig(int roomconfig) {
		Roomconfig = roomconfig;
	}
	public int getStarRating() {
		return starRating;
	}
	public void setStarRating(int starRating) {
		this.starRating = starRating;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getUpdated() {
		return updated;
	}
	public void setUpdated(String updated) {
		this.updated = updated;
	}
	public int getOffersCuponId() {
		return offersCuponId;
	}
	public void setOffersCuponId(int offersCuponId) {
		this.offersCuponId = offersCuponId;
	}
	public int getBookNowBookingId() {
		return BookNowBookingId;
	}
	public void setBookNowBookingId(int bookNowBookingId) {
		BookNowBookingId = bookNowBookingId;
	}
	@Override
	public String toString() {
		return "ViewDetails [roomId=" + roomId + ", name=" + name + ", checkin=" + checkin + ", checkout=" + checkout
				+ ", Guestconfig=" + Guestconfig + ", Roomconfig=" + Roomconfig + ", starRating=" + starRating
				+ ", currency=" + currency + ", description=" + description + ", created=" + created + ", updated="
				+ updated + ", offersCuponId=" + offersCuponId + ", BookNowBookingId=" + BookNowBookingId + "]";
	}
	
	
    
    
}
