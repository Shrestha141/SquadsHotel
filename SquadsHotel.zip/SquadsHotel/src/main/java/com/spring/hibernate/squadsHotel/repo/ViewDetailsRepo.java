package com.spring.hibernate.squadsHotel.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.hibernate.squadsHotel.model.ViewDetails;


public interface ViewDetailsRepo extends JpaRepository<ViewDetails, Integer>{

}
