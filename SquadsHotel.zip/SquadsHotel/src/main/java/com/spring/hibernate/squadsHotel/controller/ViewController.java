package com.spring.hibernate.squadsHotel.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.hibernate.squadsHotel.model.ViewDetails;
import com.spring.hibernate.squadsHotel.repo.ViewDetailsRepo;



@RestController
@RequestMapping("/v1")
public class ViewController {
	
	@Autowired
	private ViewDetailsRepo detailsRepo;

	@GetMapping("{id}")
	public Optional<ViewDetails> getHotelById(@PathVariable int id){
		return detailsRepo.findById(id);
	}
}
