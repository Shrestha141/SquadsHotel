package com.spring.hibernate.squadsHotel.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.spring.hibernate.squadsHotel.model.Location;
import com.spring.hibernate.squadsHotel.service.LocationService;


@RestController
public class SearchController {
	
	@Autowired
	private LocationService obj;
	
	@GetMapping("/hotelList")	
	public List<Location> getAllHotels(){
		return obj.getHotels();
		
	}
	
	@GetMapping("/{id}")
	public Optional<Location> getHotel(@PathVariable long id){
		return obj.getHotelById(id);
		
	}

	@GetMapping("/hotels/{place}")
	public List<Location> getHotels(@PathVariable String place) {
		return obj.getHotelByPlace(place);
	}
	
	@GetMapping("/hotel/{name}")
	public List<Location> getByHotelsName(@PathVariable String name) {
		return obj.getHotelsByName(name);
	}
	
}
