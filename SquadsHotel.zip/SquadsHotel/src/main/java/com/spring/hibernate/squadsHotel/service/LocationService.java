package com.spring.hibernate.squadsHotel.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.spring.hibernate.squadsHotel.model.Location;
import com.spring.hibernate.squadsHotel.repo.LocationRepo;



@Service
public class LocationService {
	@Autowired
	private LocationRepo locationRepo;

	public List<Location> getHotels() {
		return locationRepo.findAll();
	}

	
	public Optional<Location> getHotelById(@PathVariable long id){
		return locationRepo.findById(id);
	}
	
	
	public List<Location> getHotelByPlace(@PathVariable String place) {
		return locationRepo.findByplace(place);
	}
	

	public List<Location> getHotelsByName(@PathVariable String name) {
		return locationRepo.findByname(name);
	}
	
	
}
