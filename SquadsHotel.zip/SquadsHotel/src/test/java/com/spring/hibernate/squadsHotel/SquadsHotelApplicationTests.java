package com.spring.hibernate.squadsHotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SquadsHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
